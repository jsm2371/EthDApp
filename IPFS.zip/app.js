const express = require('express');//express모듈 
const app = express();//express모듈의 함수 express를 호출.

const fs = require('fs');//filesystem모듈

var multer  = require('multer')//multer모듈(파일 업로드 모듈)
var upload = multer({ dest: 'uploads/' })//multer모듈로 업로드한 파일이 저장될 경로를 uploads로 
console.log(upload)

var ipfsAPI = require('ipfs-api')//Importing the module 
var ipfs = ipfsAPI('ipfs.infura.io', '5001', {protocol: 'https'})// connect to ipfs daemon API server

app.get('/', function(req, res){
    //res.send('Hello World')
    res.sendFile(__dirname + '/public/index.html');//•res.sendFile(path, [options], [callback]) : path의 파일을 읽고 해당 내용을 클라이언트로 전송한다.
})

app.post('/profile', upload.single('avatar'), function(req, res, next){
    console.log(req.file);//req객체에 실어진 file을 출력
    var data = (fs.readFileSync(req.file.path));//모든 파일을 버퍼로 읽기
    console.log('test입니다.' + data);
    ipfs.add(data, function(err, file){
        if(err){
            console.log(err);
        }
        console.log(file);
        res.send(file[0].hash);
    })//
})

app.get('/download/:ID', function(req, res){
    console.log(req.params.ID);
    res.redirect('https://ipfs.io/ipfs/' + req.params.ID);
})

app.listen(3000);